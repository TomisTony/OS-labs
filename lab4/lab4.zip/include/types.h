#ifndef _TYPE_H
#define _TYPE_H

typedef unsigned long uint64;

#endif
